import java.util.Scanner;

// 삽입 정렬
public class InsertionSort {
    public void sort(int[] array) {
        for (int i=1; i < array.length; i++) {
            int key = array[i];
            for (int j=i-1; j >= 0; j--) {
                if (key < array[j]) {
                    array[j+1] = array[j];
                }
                else {
                    array[j+1] = key;
                    break;
                }
            }
        }
        for(int n : array) {
            System.out.print(n + " ");
        }
    }
}

// 테스트
class Test {
    public static void main(String[] args) {
        System.out.print("정렬할 수를 입력하세요 ex) 1,4,5,3 >> ");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        String[] s = input.split(",");
        int[] array = new int[s.length];
        for(int i=0; i<s.length; i++) {
            array[i] = Integer.parseInt(s[i]);
        }
        InsertionSort insertion = new InsertionSort();
        insertion.sort(array);
    }
}